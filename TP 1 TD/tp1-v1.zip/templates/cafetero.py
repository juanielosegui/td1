from typing import List

def filtrar_solo_CAFE(...) ...:
    '''
    completar docstring
    '''

def es_cafetero(...) ...:
    '''
    completar docstring
    '''

def n_esimo_cafetero(...) ...:
    '''
    completar docstring
    '''

def cafeteros_entre(...) ...:
    '''
    completar docstring
    '''

# Definir también las funciones auxiliares que se consideren necesarias.
