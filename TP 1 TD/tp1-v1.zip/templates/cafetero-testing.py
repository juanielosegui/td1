import unittest

# Se importa el código a testear.
from cafetero import filtrar_solo_CAFE, es_cafetero, n_esimo_cafetero, cafeteros_entre

#####################################################################

class TestCafetero(unittest.TestCase):
    def test_...(self):
        ...

    def test_...(self):
        ...

## y así con el resto de las funciones a testear.

unittest.main()
